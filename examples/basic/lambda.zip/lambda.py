def handler(event, context):
    print("hello basic example!")
